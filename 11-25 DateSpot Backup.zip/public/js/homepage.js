function goToSignUp(){
    window.location.href = "/users/signup";
}

function goToLogin(){
    window.location.href = "/users/login";
}