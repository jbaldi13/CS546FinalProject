DateSpot

A dating website that initially prompts users to select their dating preferences in which they will
choose five place sub-categories and five event sub-categories that they enjoy going to/doing.
Then, the website recommends people with compatible dating preferences to the user. Finally,
after a match between users, it uses the Yelp Fusion API and Eventbrite API (which gives info
on different events) to recommend places nearby or upcoming events that fall under the
mutually specified sub-category selections for date ideas. For example, if both users like pop
music, it could recommend upcoming pop concerts. Or if they both like coffee, it could
recommend local coffee shops.
